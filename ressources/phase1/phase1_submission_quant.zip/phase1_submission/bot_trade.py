import numpy as np

# --- GLOBAL STATE ---
history = []

def make_decision(epoch: int, price: float) -> dict:
    """
    Stratégie: Z-Score Mean Reversion avec Filtre de Vélocité.
    Optimisée pour le Hackathon (PnL + Drawdown Control).
    """
    global history
    
    # 1. Mise à jour de l'historique
    history.append(price)
    
    # --- WARMUP PHASE (30 époques) ---
    if len(history) < 30:
        return {'Asset A': 0.0, 'Cash': 1.0}

    # --- INDICATEURS (Numpy) ---
    # Fenêtre glissante de 30 périodes
    window_size = 30
    recent_prices = np.array(history[-window_size:])
    
    rolling_mean = np.mean(recent_prices)
    rolling_std = np.std(recent_prices)
    
    # Sécurité division par zéro
    if rolling_std == 0:
        return {'Asset A': 0.0, 'Cash': 1.0}
        
    # Z-SCORE : Distance statistique à la moyenne
    z_score = (price - rolling_mean) / rolling_std
    
    # VÉLOCITÉ : Direction immédiate du prix (Dérivée)
    velocity = 0.0
    if len(history) >= 2:
        velocity = history[-1] - history[-2]

    # --- LOGIQUE DE DÉCISION ---
    
    # 1. ACHAT FORT (Buy the Dip)
    # On achète seulement si le prix est statistiquement effondré (Z < -2)
    # ET qu'il commence à remonter (Velocity > 0) -> On attrape le rebond, pas le couteau.
    if z_score < -2.0 and velocity > 0:
        return {'Asset A': 1.0, 'Cash': 0.0}
    
    # 2. VENTE (Take Profit / Sécurité)
    # Si le prix est trop haut (Z > 1.5) OU si on est revenu à la moyenne (Z ~ 0)
    elif z_score > 1.5 or abs(z_score) < 0.5:
        return {'Asset A': 0.0, 'Cash': 1.0}
        
    # 3. MAINTIEN (Hystérésis)
    # Si on est entre les deux (ex: Z = -1.0), on suit la tendance court terme (Vélocité)
    else:
        # Si on est en zone de rebond (-2 à 0) et que ça monte, on garde.
        if -2.0 <= z_score < 0.0 and velocity > 0:
             return {'Asset A': 1.0, 'Cash': 0.0}
        # Sinon (ça baisse ou zone neutre), on reste cash.
        return {'Asset A': 0.0, 'Cash': 1.0}
